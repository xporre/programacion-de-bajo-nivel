import _libreria as lib
from _lib import *

libro("titulo","autor","editorial",10)
libro("titulo","autor","editorial",10)
libro("titulo","autor","editorial",10)
libro("titulo","autor","editorial",10)
libro("titulo","autor","editorial",10)
libro("titulo","autor","editorial",10)




clientes("nombre","apellido",000000000,k,999999999,"email");
clientes("nombre","apellido",000000000,k,999999999,"email");
clientes("nombre","apellido",000000000,k,999999999,"email");

